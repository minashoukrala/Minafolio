import { defineConfig } from "vite";

export default defineConfig({
  base: "/my-portfolio/", // ← Make sure this matches your GitHub repo name
});